module edu.lawrence.pongserver {
    requires javafx.controls;
    exports edu.lawrence.pongserver;
}