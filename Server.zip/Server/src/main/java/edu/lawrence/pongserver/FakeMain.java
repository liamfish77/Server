package edu.lawrence.pongserver;

/**
 *
 * @author Joe Gregg
 */
public class FakeMain {
    public static void main(String[] args) {
        App.main(args);
    }
}
